import tkinter as tk
from tkinter import messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import time
import serial
import os

# Configurações da porta serial
PORTA = 'COM9'  
BAUD_RATE = 115200  # Mesmo baud rate configurado no Arduino

# Inicializa a conexão serial
try:
    arduino = serial.Serial(PORTA, BAUD_RATE)
    time.sleep(2)  # Espera a conexão inicializar
    print("Conexão com o Arduino estabelecida.")
except serial.SerialException:
    print("Não foi possível conectar ao Arduino.")
    arduino = None  # Define como None para evitar erros posteriores

# Parâmetros personalizáveis
UPDATE_INTERVAL = 0  # Intervalo de atualização em milissegundos

# Inicializa os dados do gráfico
time_data = []
v1_data = []
v2_data = []
counter = 0  # Contador para ignorar valores

# Cria a figura e os eixos
figure, ax = plt.subplots(figsize=(10, 4))

# Tempo inicial
start_time = None
refresh_time = None  # Variável para armazenar o tempo de refresh

# Variável para armazenar o estado da animação
ani = None
is_paused = False
awaiting_input = True  # Nova variável para rastrear se estamos aguardando um valor de entrada

# Variável para armazenar o valor inserido pelo usuário
user_input_value = 0

def get_next_file_counter():#para saber o numero que deve atribuir à  imagem guardada
    counter = 0
    while os.path.exists(rf"C:\Users\madru\OneDrive\Documentos\ISEL\01-OEF3\PID_guardados\grafico_imagem_{counter}.png"):
        counter += 1
    return counter

save_counter = get_next_file_counter() 

def update_plot(frame):#para ler os valores do arduino e dar update ao grafico
    global time_data, v1_data, v2_data, start_time, refresh_time, counter, is_paused

    # Não atualiza se o gráfico está pausado ou aguardando entrada
    if is_paused or start_time is None or awaiting_input:
        return  
    
    # Lê os dados do Arduino
    if arduino and arduino.in_waiting > 0:
        try:
            dados = arduino.readline().decode('ISO-8859-1', errors='ignore').strip()  # Lê e decodifica a linha de dados
            valores = dados.split(',')  # Separa os valores por vírgula
            
            if len(valores) >= 2:
                valor1 = float(valores[0])  # Primeiro valor do Arduino
                valor2 = float(valores[1])  # Segundo valor do Arduino

                counter += 1  # Incrementa o contador

                # Guarda os valores apenas de 5 em 5
                
                tempo_corrente = (time.time() - start_time) * 1000  # Tempo em milissegundos



                time_data.append(tempo_corrente)
                v1_data.append(user_input_value)  # Usa o valor inserido pelo usuário
                v2_data.append(valor2)

                ax.clear()
                ax.plot(time_data, v1_data, color='blue', label=r'$\theta_{desired}$')
                ax.plot(time_data, v2_data, color='red', label=r'$\theta_{actual}$')
                ax.set_xlabel('Tempo (ms)')
                ax.set_ylabel(r'$\theta\;(°)$')
                ax.set_title(r'Gráfico de $\theta $ em Tempo Real')
                ax.grid(True)
                ax.set_ylim(min(min(v1_data), min(v2_data), 0), max(max(v1_data)+5, max(v2_data), 10)) 
                    
                    # Ajuste do eixo X
                if refresh_time is not None:
                        ax.set_xlim(left=refresh_time, right=tempo_corrente)
                else:
                        ax.set_xlim(left=0, right=tempo_corrente)

                ax.legend()
        except ValueError:
            print("Erro ao processar os valores recebidos do Arduino.")

def toggle_plot():#para pausar o gráfico
    global ani, is_paused
    if is_paused:
        ani.event_source.start()
        is_paused = False
        toggle_button.config(text="Parar Gráfico")
        print("Gráfico retomado.")
    else:
        ani.event_source.stop()
        is_paused = True
        toggle_button.config(text="Retomar Gráfico")
        print("Gráfico pausado.")

def save_plot_image():#para guardar a imagem do gráfico com o numero anteriormente atribuido
    global save_counter
    filename = rf"C:\Users\madru\OneDrive\Documentos\ISEL\01-OEF3\PID_guardados\grafico_imagem_{save_counter}.png"
    figure.savefig(filename)
    save_counter += 1
    print(f"Imagem do gráfico salva como '{filename}'.")

def refresh_plot():#para apagar os valores anteriores do gráfico
    global time_data, v1_data, v2_data, refresh_time
    refresh_time = (time.time() - start_time) * 1000  # Tempo em milissegundos
    time_data.clear()
    v1_data.clear()
    v2_data.clear()
    print(f"Gráfico atualizado e tempo de refresh ajustado para {refresh_time} ms.")

def restart_plot():#para reiniciar o ensaio
    global time_data, v1_data, v2_data, start_time, awaiting_input
    time_data.clear()
    v1_data.clear()
    v2_data.clear()
    start_time = None  # Reinicia o tempo inicial
    awaiting_input = True  # Define como verdadeiro para aguardar um novo valor de entrada
    ax.clear()
    ax.set_xlim(left=0, right=10)
    ax.set_ylim(0, 10)
    ax.set_xlabel('Tempo (ms)')
    ax.set_ylabel(r'$\theta\;(°)$')
    ax.set_title(r'Gráfico de $\theta $ em Tempo Real')
    ax.grid(True)
    canvas.draw()
    if arduino:
     arduino.write(f"{-1}\n".encode('utf-8'))

    print("Gráfico reiniciado e valores apagados. Aguardando novo valor de entrada.")

def close_application():#para fechar a aplicação e mandar o valor -1 para o arduino (para parar o motor)
    if arduino:
        arduino.write(f"{-1}\n".encode('utf-8'))
        arduino.close()
    root.quit()
    root.destroy()
    print("Aplicação encerrada.")

def open_input_window():#para enviar um novo setpoint para o arduino
    def confirm_input(event=None):
        global user_input_value, awaiting_input, start_time
        try:
            user_input_value_test = float(input_entry.get())
            if 0 < user_input_value_test < 50:
                user_input_value = user_input_value_test
                if awaiting_input:
                    start_time = time.time()  # Reinicia o tempo ao receber um novo valor
                    awaiting_input = False  # Para de aguardar novos valores
                # Envia o valor ao Arduino
                if arduino:
                    arduino.write(f"{user_input_value}\n".encode('utf-8'))
                    print(f"Valor enviado para o Arduino: {user_input_value}")
                input_window.destroy()
            else:
                messagebox.showerror("Erro", "Insira um valor entre 0 e 50.")
        except ValueError:
            messagebox.showerror("Erro", "Insira um valor numérico válido.")
    
    input_window = tk.Toplevel(root)
    input_window.title("Inserir Valor")
    tk.Label(input_window, text="Insira um valor entre 0 e 50:").pack(padx=10, pady=5)
    input_entry = tk.Entry(input_window)
    input_entry.pack(padx=10, pady=5)
    input_entry.bind('<Return>', confirm_input)  # Permite usar a tecla Enter para confirmar
    tk.Button(input_window, text="Confirmar", command=confirm_input).pack(pady=10)
    input_entry.focus_set()  # Define o foco na caixa de entrada

root = tk.Tk()
root.title("Gráfico em Tempo Real")

canvas = FigureCanvasTkAgg(figure, root)
canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

button_frame = tk.Frame(root)
button_frame.pack(side=tk.TOP, fill=tk.X, pady=5)

toggle_button = tk.Button(button_frame, text="Parar Gráfico", command=toggle_plot)
toggle_button.pack(side=tk.LEFT, padx=5)

save_button = tk.Button(button_frame, text="Salvar Imagem", command=save_plot_image)
save_button.pack(side=tk.LEFT, padx=5)

refresh_button = tk.Button(button_frame, text="Refresh", command=refresh_plot)
refresh_button.pack(side=tk.LEFT, padx=5)

restart_button = tk.Button(button_frame, text="Restart", command=restart_plot)
restart_button.pack(side=tk.LEFT, padx=5)

input_button = tk.Button(button_frame, text="Enviar Valor", command=open_input_window)
input_button.pack(side=tk.LEFT, padx=5)

close_button = tk.Button(button_frame, text="Fechar", command=close_application)
close_button.pack(side=tk.LEFT, padx=5)

ani = animation.FuncAnimation(figure, update_plot, interval=UPDATE_INTERVAL, cache_frame_data=False)

root.protocol("WM_DELETE_WINDOW", close_application)

root.mainloop()