import numpy as np

Amostra=["Latão","Alumínio ","Chumbo","Aço","Vidro","Cerâmica","Polietileno"]
den_teorica=["1.6-2.5","2.6-2.9","10.7-11.3","2.5","7.2-8.9","7.5-8.1","~0.9"]
m_ar=[19.3,13.0,65.6,6.7,5.3,58.7,23.4]
m_susp=[17.1 , 8.4 , 59.7 , 5.8 , 3.2 , 29.4]
den=[8.77 , 2.83 , 11.12 , 7.44 , 2.52 , 2.00, 0.87]
m_c=21.0
m_total=17.4

err_den=np.array([])
print("Amostra,m_v teórica(gcm^-3), m_v experimental(gcm^-3)")
for i in range(0,len(m_ar)):
 if(i==6):
    erro2=den[i]*((0.1/m_ar[i])**2+(0.14/(m_c-m_total+m_ar[i]))**2)**0.5
    print(rf"{Amostra[i]},{den_teorica[i]},{den[i]} pm {round(erro2,2)}")
 else:
     erro=den[i]*((0.1/m_ar[i])**2+(0.14/(m_ar[i]-m_susp[i]))**2)**0.5
     print(rf"{Amostra[i]},{den_teorica[i]},{den[i]} pm {round(erro,2)}")

print("_____________________________________________________")
print("Amostra, m_{ar}, m_{susp}, m_c, m_{total}, Delta m ")

