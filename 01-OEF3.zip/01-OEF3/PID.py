import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import random
import time

# Parâmetros personalizáveis
UPDATE_INTERVAL = 100  # Intervalo de atualização em milissegundos
MIN_VALUE = 0  # Valor mínimo aleatório
MAX_VALUE = 100  # Valor máximo aleatório

# Inicializa os dados do gráfico
x_data = []
y_data = []

# Cria a figura e os eixos
figure, ax = plt.subplots(figsize=(12, 6))

# Tempo inicial
start_time = time.time()

def update_plot(frame):
    current_time = time.time() - start_time  # Tempo desde o início em segundos
    
    # Gera novos dados aleatórios
    new_data = random.uniform(MIN_VALUE, MAX_VALUE)
    y_data.append(new_data)
    x_data.append(current_time)

    # Atualiza a linha do gráfico sem limpar
    ax.clear()  # Limpa o conteúdo dos eixos
    ax.plot(x_data, y_data, color='blue')
    ax.set_xlabel('Tempo (s)')
    ax.set_ylabel('Valor')
    ax.set_title('Gráfico de Valores Aleatórios em Tempo Real')
    ax.grid(True)
    ax.set_ylim(MIN_VALUE, MAX_VALUE)
    ax.set_xlim(0, max(x_data))  # Mantém o limite inferior em 0

# Função para parar a atualização e fechar a janela
def stop_plot():
    root.quit()
    root.destroy()

# Cria a janela principal
root = tk.Tk()
root.title("Gráfico em Tempo Real")

# Cria a canvas e empacota na janela
canvas = FigureCanvasTkAgg(figure, root)
canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

# Cria o botão para parar o gráfico
stop_button = tk.Button(root, text="Parar", command=stop_plot)
stop_button.pack()

# Inicializa a animação com cache_frame_data=False
ani = animation.FuncAnimation(figure, update_plot, interval=UPDATE_INTERVAL, cache_frame_data=False)

# Inicia o loop principal da janela
root.mainloop()
