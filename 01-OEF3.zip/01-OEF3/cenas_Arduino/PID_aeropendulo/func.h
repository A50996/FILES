bool tempo(int intervalo) {//para fazer um "delay" sem parar o código

  static long t0 = 0;  // Declare t0 as static and initialize

  if (intervalo == -1) {
    t0 = millis();
  } else {
    return millis() - t0 > intervalo;
  }
  return false;
}

double pid(double error) {//calculo do PID
  double proportional = error;
  integral += error * dt;
  double derivative = (error - previous) / dt;
  previous = error;
  double output = (kp * proportional) + (ki * integral) + (kd * derivative);
  return output;
}

float input(float x) {//atribui um novo setpoint
  String inputString = Serial.readStringUntil('\n');  // Read until newline
  if(inputString.toFloat()==-1.0) return -1.0;
  else if (inputString.toFloat() < 0.0 || inputString.toFloat() > 50.0)  return x;
  else return inputString.toFloat();

}


