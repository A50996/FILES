import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import time
import os
import serial

# Configurações da porta serial
ser = serial.Serial('COM3', 9600)  # Substitua 'COM3' pela porta correta do seu Arduino

# Parâmetros personalizáveis
UPDATE_INTERVAL = 100  # Intervalo de atualização em milissegundos

# Inicializa os dados do gráfico
time_data = []
v1_data = []
v2_data = []

# Cria a figura e os eixos
figure, ax = plt.subplots(figsize=(10, 4))

# Tempo inicial
start_time = None
refresh_time = None  # Variável para armazenar o tempo de refresh

# Variável para armazenar o estado da animação
ani = None
is_paused = False

# Variável para armazenar o valor inserido pelo usuário
user_input_value = None

# Contador de pares de valores recebidos
pair_counter = 0

# Defina o contador baseado no número de arquivos existentes
def get_next_file_counter():
    counter = 0
    while os.path.exists(rf"C:\Users\madru\OneDrive\Documentos\ISEL\01-OEF3\PID_guardados\grafico_imagem_{counter}.png"):
        counter += 1
    return counter

save_counter = get_next_file_counter()  # Inicializa o contador único

def update_plot(frame):
    global time_data, v1_data, v2_data, start_time, refresh_time, pair_counter

    if start_time is None:
        start_time = time.time()
    
    # Lê valores do Arduino
    if ser.in_waiting:
        arduino_data = ser.readline().decode('utf-8').strip()
        try:
            # Converte os valores para float antes de processar
            values = list(map(float, arduino_data.split(',')))
            if len(values) == 2:
                pair_counter += 1
                if pair_counter == 3:  # Guarda a cada terceiro par de valores
                    tempo_corrente = (time.time() - start_time) * 1000  # Tempo em milissegundos
                    time_data.append(tempo_corrente)
                    v1_data.append(values[0])
                    v2_data.append(values[1])
                    pair_counter = 0  # Reseta o contador após guardar os valores
        except ValueError:
            print(f"Erro ao processar dados: {arduino_data}")

    # Atualiza o gráfico se os dados foram atualizados
    if time_data and v1_data and v2_data:
        ax.clear()
        ax.plot(time_data, v1_data, color='blue', label=r'$\theta_{desired}$')
        ax.plot(time_data, v2_data, color='red', label=r'$\theta_{actual}$')
        ax.set_xlabel('Tempo (ms)')
        ax.set_ylabel(r'$\theta\;(°)$')
        ax.set_title(r'Gráfico de $\theta $ em Tempo Real')
        ax.grid(True)
        ax.set_ylim(min(min(v1_data), min(v2_data), 0), max(max(v1_data), max(v2_data), 10)) 
        
        # Ajuste do eixo X
        if refresh_time is not None:
            ax.set_xlim(left=refresh_time, right=tempo_corrente)
        else:
            ax.set_xlim(left=0, right=tempo_corrente)
        
        y_ticks = np.arange(0, max(max(v1_data), max(v2_data), 10) + 1, 1)
        ax.set_yticks(y_ticks)
        ax.legend()

def toggle_plot():
    global ani, is_paused
    if is_paused:
        ani.event_source.start()
        is_paused = False
        toggle_button.config(text="Parar Gráfico")
        print("Gráfico retomado.")
    else:
        ani.event_source.stop()
        is_paused = True
        toggle_button.config(text="Retomar Gráfico")
        print("Gráfico pausado.")

def save_plot_image():
    global save_counter
    filename = rf"C:\Users\madru\OneDrive\Documentos\ISEL\01-OEF3\PID_guardados\grafico_imagem_{save_counter}.png"
    figure.savefig(filename)
    save_counter += 1
    print(f"Imagem do gráfico salva como '{filename}'.")

def refresh_plot():
    global time_data, v1_data, v2_data, refresh_time
    refresh_time = (time.time() - start_time) * 1000  # Tempo em milissegundos
    time_data.clear()
    v1_data.clear()
    v2_data.clear()
    print(f"Gráfico atualizado e tempo de refresh ajustado para {refresh_time} ms.")

def close_application():
    ser.close()
    root.quit()
    root.destroy()
    print("Aplicação encerrada.")

def open_input_window():
    def confirm_input(event=None):
        global user_input_value
        user_input_value = input_entry.get()
        print(f"Valor inserido: {user_input_value}")
        input_window.destroy()
    
    input_window = tk.Toplevel(root)
    input_window.title("Inserir Valor")
    tk.Label(input_window, text="Insira um valor:").pack(padx=10, pady=5)
    input_entry = tk.Entry(input_window)
    input_entry.pack(padx=10, pady=5)
    input_entry.bind('<Return>', confirm_input)  # Permite usar a tecla Enter para confirmar
    tk.Button(input_window, text="Confirmar", command=confirm_input).pack(pady=10)
    input_entry.focus_set()  # Define o foco na caixa de entrada

root = tk.Tk()
root.title("Gráfico em Tempo Real")

canvas = FigureCanvasTkAgg(figure, root)
canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

# Frame para os botões
button_frame = tk.Frame(root)
button_frame.pack(side=tk.TOP, fill=tk.X, pady=5)

# Botão para pausar e retomar o gráfico
toggle_button = tk.Button(button_frame, text="Parar Gráfico", command=toggle_plot)
toggle_button.pack(side=tk.LEFT, padx=5)

# Botão para salvar a imagem do gráfico
save_button = tk.Button(button_frame, text="Salvar Imagem", command=save_plot_image)
save_button.pack(side=tk.LEFT, padx=5)

# Botão para atualizar o gráfico
refresh_button = tk.Button(button_frame, text="Refresh", command=refresh_plot)
refresh_button.pack(side=tk.LEFT, padx=5)

# Botão para abrir a janela de inserção de valor
input_button = tk.Button(button_frame, text="Enviar Valor", command=open_input_window)
input_button.pack(side=tk.LEFT, padx=5)

# Botão para fechar a aplicação
close_button = tk.Button(button_frame, text="Fechar", command=close_application)
close_button.pack(side=tk.LEFT, padx=5)

# Inicializa a animação com cache_frame_data=False
ani = animation.FuncAnimation(figure, update_plot, interval=UPDATE_INTERVAL, cache_frame_data=False)

# Captura o evento de fechamento da janela
root.protocol("WM_DELETE_WINDOW", close_application)

# Inicia o loop principal da janela
root.mainloop()
